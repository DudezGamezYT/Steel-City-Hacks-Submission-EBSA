'''
#education
#
from colorama import Fore, Back, Style
import tkinter as tk
import math
import time

#
print(Fore.LIGHTBLUE_EX+ " VOLUME & AREA CALCULATOR")
print(Fore.GREEN+ " ________________________")
print(Fore.WHITE + "\n\n click start to continue" + Fore.GREEN)
#



#
def pentagon_area(side):
  return str((1/4)*math.sqrt(5*(5+2*math.sqrt(5)*side**2)))
#
def square_area(length):
  return str(length**2)
#
def sphere_vol(radius): #
	return str((4 / 3) * math.pi * (radius**3))
#
def cube_vol(side): #
	return str(side**3)
#
def cylinder_vol(radius, height): #
	return str((math.pi * (radius**2)) * height)
#
def cuboid_vol(width, length, height): #
	return str(width * length * height)
#
def cone_vol(radius, height): #
	return str(math.pi * (radius**2)) * (height / 3)
#
def pyramid_vol(length, width, height): #
  return str((length * width * height) / 3)
#
def circle_area(radius):
  return str(radius**2 * math.pi)
#
def triangle_area(height, base):
  return str((height * base )/2)
# 
def rhombus_area(d1, d2):
  return str((d1 * d2)/2)
#
def hexagon_area(s):
  return str(3 * math.sqrt(3)/2)
  
def sphere_sa(radius):
  return str(4 * math.pi * (radius ** 2))
  
def cube_sa(length):
  return str(6 * (length**2))

def cylinder_sa(radius, height):
  return str(2*math.pi* radius * height + 2 * math.pi * (radius**2))

def cuboid_sa(length, width, height):
  return str((2*length*width) + (2*length*height) + (2*height*width))

def cone_sa(radius, height):
  return str(math.pi*radius*(radius+math.sqrt(((height**2)+(radius**2)))))

def pyramid_sa(length, width, height):
  return str(length*width+length*(math.sqrt((width/2)**2+height**2+width))*math.sqrt((width/2)**2+height**2))

def hexpris_sa(base, height):
  return str(6*base*height+3*math.sqrt(3)*base**2)

def petpris_sa(base, height):
  return str(5*base*height+1/2*math.sqrt(5*(5+2*math.sqrt(5)))*(base**2))

#def tripris_sa(base, height):
#  return str((base*height*3)+((math.sqrt(3)/4)*base**2))
#  return 

class tkc(tk.Frame):
  def __init__(self, master=None):
    super().__init__(master)
    self.master = master
    self.pack()
    self.create_widgets()
  
  def create_widgets(self):
    self.hi_there = tk.Button(self)
    self.hi_there["text"] = "START"
    self.hi_there["command"] = self.pro
    self.hi_there.pack(side = 'bottom')

  def pro(self):
    x = input(Fore.LIGHTCYAN_EX + "\nWould you like to find the area / volume of a \n2D[1] or \n3D[2] object?\n")     
    if x == '1':   
      y = input("Which of the following would you like to find the area of: \n Square[1], Circle[2], Triangle[3], Pentagon[4], Hexagon[5], Rhombus[6]?\n ")
      
      if y == '1': 
        z = float(input("What is the side length of the square? \n"))
        x= square_area(z)
        print(Fore.WHITE+ "Your Area is " + Fore.GREEN+x)
      elif y == '2':
        z = float(input("What is the radius of the circle? \n"))
        x=circle_area(z)
        print(Fore.WHITE+"Your Area is " + Fore.GREEN+x)
      elif y == '3':
        z = float(input("What is the base of the triangle? \n"))
        z2 = float(input("What is the height of the triangle? \n"))
        x = triangle_area(z2,z)
        print(Fore.WHITE+"Your Area is "+Fore.GREEN+x)
      elif y == '4':
        x = float(input("What is the side length of the pentagon? \n"))
        y = pentagon_area(x)
        print(Fore.WHITE+"Your Area is "+Fore.GREEN+str(y))
        
        
        #1/4*sqrt(5(5+2sqrt5))a^2
      elif y == '5':
        a = float(input("What is the side length of the hexagon?\n"))
        # hexagon area sl * a * 3 1
        ha = hexagon_area(a)
        print(Fore.WHITE+"Your Area is "+Fore.GREEN + ha )

      elif y == '6':
        d1 = float(input("What is the length of a diagonal?\n"))
        d2 = float(input("What is the length of the other diagonal?\n"))	
        ra = rhombus_area(d1,d2)
        print(Fore.WHITE+"Your Area is "+Fore.GREEN + ra) 
        
      else:
        print(Fore.LIGHTCYAN_EX+"\nPlease enter a valid number\n" + Fore.RED+"OR ELSE")
    elif x == '2':
      y = input("Volume[1] or surface area [2]? ")
      if(y == '1'):
        y = input(
            "Which of the following would you like to find the volume of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6], Prism[7]\n")
        if y == '1':
          i1 = float(input("Enter the radius "))
          z = sphere_vol(i1)
        elif y == '2':
          i1 = float(input("Enter a side length "))
          z = cube_vol(i1)
        elif y == '3':
          i1 = float(input("Enter the base radius "))
          i2 = float(input("Enter the height "))
          z = cylinder_vol(i1, i2)
        elif y == '4':
          i1 = float(input("Enter the width "))
          i2 = float(input("Enter the length "))
          i3 = float(input("Enter the height "))
          z = cuboid_vol(i1, i2, i3)
        elif y == '5':
          i1 = float(input("Enter the radius of the base circle "))
          i2 = float(input("Enter the height of the cone "))
          z = cone_vol(i1, i2)
        elif y == '6':
          i1 = float(input("Enter the length "))
          i2 = float(input("Enter the width "))
          i3 = float(input("Enter the height "))
          z = pyramid_vol(i1, i2, i3)
        elif y == '7':
          z = input("What type of prism would you like to find the volume of: Triangular[1], Pentagonal[2],or Hexgonal[3] ")
          if z == '1':
            z1 = float(input("What is the base of the triangle? "))
          
          else:
            pass
        else:
          print(Fore.LIGHTCYAN_EX + "\nPlease enter a valid number\n")
        print("Your Volume is " + Fore.GREEN + z)
      elif(y == '2'):
        y = input(
            "Which of the following would you like to find the surface area of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6], Prism[7]\n")
        if y == '1':
          i1 = float(input("Enter the radius: "))
          z = sphere_sa(i1)
        elif y == '2':
          i1 = float(input("Enter the side legth: "))
          z = cube_sa(i1)
        elif y == '3':
          i1 = float(input("Enter the radius: "))
          i2 = float(input("Enter the height: "))
          z = cylinder_sa(i1, i2)
        elif y == '4':
          i1 = float(input("Enter the length: "))
          i2 = float(input("Enter the width: "))
          i3 = float(input("Enter the height: "))
          z = cuboid_sa(i1, i2, i3)
        elif y == '5':
          i1 = float(input("Enter the radius: "))
          i2 = float(input("Enter the height: "))
          z = cone_sa(i1, i2)
        elif y == '6':
          i1 = float(input("Enter the length: "))
          i2 = float(input("Enter the width: "))
          i3 = float(input("Enter the height"))
          z = pyramid_sa(i1, i2, i3)
        elif y == '7':
          y = input("Which prism do you want the surface area of: Pentagonal[1], Hexagonal[2] \n")
          #if y == '1':
          #  i1 = float(input("\nEnter the base length: \n"))
          #  i2 = float(input("Enter the height: \n"))
          #  z = tripris_sa(i1, i2)
          if y == '1':
            i1 = float(input("\nEnter the base length: \n"))
            i2 = float(input("Enter the height: \n"))
            z = petpris_sa(i1, i2)
          elif y == '2':
            i1 = float(input("\nEnter the base length: \n"))
            i2 = float(input("Enter the height: \n"))
            z = hexpris_sa(i1, i2)
          else:
            print(Fore.RED + "Please enter a valid number")
          print("Your surface area is "+ Fore.GREEN + z)
        else:
          print("Please enter a valid number")
      else:
        print("Please enter a valid number")
    else:
      print(Fore.WHITE + "\nPlease enter a valid number\n")
      time.sleep(1.5)
      print(Fore.RED + "OR ELSE")

root = tk.Tk()
app = tkc(master = root)
app.mainloop()

#'''
