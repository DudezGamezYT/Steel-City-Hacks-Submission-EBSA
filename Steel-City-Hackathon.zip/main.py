#'''
#eddie.yang.zh@gmail.com
#bhuang@nastudents.org
#shaifali.kapilin@gmail.com
#education
#
from colorama import Fore, Back, Style
from PIL import ImageTk, Image
import tkinter as tk
import math
import time

#
print(Fore.LIGHTBLUE_EX+ " VOLUME & AREA CALCULATOR")
print(Fore.GREEN+ " ________________________")
print(Fore.WHITE + "\n\n click start to continue" + Fore.GREEN)
#

global z
z = None
global u
u = None

#
def pentagon_area(side):
  return str((1/4)*math.sqrt(5*(5+2*math.sqrt(5)*side**2)))
#
def square_area(length):
  return str(length**2)
#
def sphere_vol(radius): #
	return str((4 / 3) * math.pi * (radius**3))
#
def cube_vol(side): #
	return str(side**3)
#
def cylinder_vol(radius, height): #
	return str((math.pi * (radius**2)) * height)
#
def cuboid_vol(width, length, height): #
	return str(width * length * height)
#
def cone_vol(radius, height): #
	return str(math.pi * (radius**2)) * (height / 3)
#
def pyramid_vol(length, width, height): #
  return str((length * width * height) / 3)
#
def circle_area(radius):
  return str(radius**2 * math.pi)
#
def triangle_area(height, base):
  return str((height * base )/2)
# 
def rhombus_area(d1, d2):
  return str((d1 * d2)/2)
#
def hexagon_area(s):
  return str(3 * math.sqrt(3)/2*s**2)
  
def sphere_sa(radius):
  return str(4 * math.pi * (radius ** 2))
  
def cube_sa(length):
  return str(6 * (length**2))

def cylinder_sa(radius, height):
  return str(2*math.pi* radius * height + 2 * math.pi * (radius**2))

def cuboid_sa(length, width, height):
  return str((2*length*width) + (2*length*height) + (2*height*width))

def cone_sa(radius, height):
  return str(math.pi*radius*(radius+math.sqrt(((height**2)+(radius**2)))))

def pyramid_sa(length, width, height):
  return str(length*width+length*(math.sqrt((width/2)**2+height**2+width))*math.sqrt((width/2)**2+height**2))

def hexpris_sa(base, height):
  return str(6*base*height+3*math.sqrt(3)*base**2)

def petpris_sa(base, height):
  return str(5*base*height+1/2*math.sqrt(5*(5+2*math.sqrt(5)))*(base**2))

def penta_prism_vol(sl, height):
  return str((1/4)*math.sqrt(5*(5+2*math.sqrt(5)))*sl**2*height)
#def tripris_sa(base, height):
#  return str((base*height*3)+((math.sqrt(3)/4)*base**2))
#  return 

class tkc(tk.Frame):
  def __init__(self, master=None, f = 0, anim = None):
    super().__init__(master)
    self.master = master
    self.f = f
    self.inp = '0'
    self.anim = anim
    self.ppane = tk.Frame(master)
    self.textc = tk.Frame(master, width = 300, height = 160)
    self.pack()
    self.textc.pack()
    self.create_widgets()

  def button1(self):
    self.inp = 1
    print("1")
  def button2(self):
    self.inp = 2
    print("2")
  def button3(self):
    self.inp = 3
    print("3")
  def button4(self):
    self.inp = 4
    print("4")
  def button5(self):
    self.inp = 5
    print("5")
  def button6(self):
    self.inp = 6
    print("6")
  def button7(self):
    self.inp = 7
    print("7")
  def buttonS(self, inpu):
    self.inp = float(inpu)
    print(inpu)
  def buttonE(self):
    exit()
  
  def create_widgets(self):
    self.hi_there = tk.Button(self)
    self.hi_there["text"] = "START"
    self.hi_there["command"] = self.pro
    self.hi_there.pack(side = "left", expand="true", fill="both")

    # interacions
    self.in1 = tk.Button(self)
    self.in1["text"] = "1"
    self.in2 = tk.Button(self)
    self.in2["text"] = "2"
    self.in3 = tk.Button(self)
    self.in3["text"] = "3"
    self.in4 = tk.Button(self)
    self.in4["text"] = "4"
    self.in5 = tk.Button(self)
    self.in5["text"] = "5"
    self.in6 = tk.Button(self)
    self.in6["text"] = "6"
    self.in7 = tk.Button(self)
    self.in7["text"] = "7"
    self.set = tk.Button(self)
    self.set["text"] = "SET CUSTOM INPUT"
    #self.end = tk.Button(self)
    #self.end["text"] = "END"

    # commandpack
    self.in1["command"] = self.button1
    self.in2["command"] = self.button2
    self.in3["command"] = self.button3
    self.in4["command"] = self.button4
    self.in5["command"] = self.button5
    self.in6["command"] = self.button6
    self.in7["command"] = self.button7 
    #self.end["command"] = self.buttonE 

    
    self.in1.pack(expand="true", fill="both", side="left")
    self.in2.pack(expand="true", fill="both", side="left")
    self.in3.pack(expand="true", fill="both", side="left")
    self.in4.pack(expand="true", fill="both", side="left")
    self.in5.pack(expand="true", fill="both", side="left")
    self.in6.pack(expand="true", fill="both", side="left")
    self.in7.pack(expand="true", fill="both", side="left")
    #self.end.pack(expand="true", fill="both", side="left")
    
    # TEXTBOX
    self.textbox = tk.Text(self)
    #self.textbox.place(x=0, y=30, height=30, width=150)
    #self.textlab = tk.Label(self)
    #self.textlab.pack(side = "top", expand = "true", fill = "both")
    #self.textbox.pack(side = "right", expand = "true", fill = "both")
    self.textbox.pack(expand="true", fill="both")
    #self.textbox.place(x=185, y=30, height=150, width=150)
    self.textbox.get("1.0", "end")

    self.set["command"] = lambda: self.buttonS(self.textbox.get("1.0", "end"))
    self.set.pack(expand="true", fill="both", side="left")

    # TEST
    #'''
    self.test = tk.Button(self)
    self.test["text"] = "TEST"
    self.test["command"] = self.tester
    self.test.pack(side = 'right')
    #'''

    # EXPERIMENTAL ANIMATION
    '''
    self.anim = tk.Label(self)
    self.anim["text"] = "click start to continue."
    self.anim.pack(side="bottom")
    '''
  
  def tester(self):
    print(self.inp)

  def create_text(self, zh):
    self.texts = tk.Button(self)
    self.texts["text"] = zh
    self.texts["command"] = self.dem
    self.texts.pack(expand="true", fill="both", side = "bottom")
      
  def dem(self):
    self.f+=1
    if(self.f>4):
      self.demo = tk.Button(self)
      self.demo["text"] = "STAHP"
      self.demo["command"] = self.end
      self.demo.pack(side = "bottom", expand = "true", fill = "both")
    self.demo = tk.Button(self)
    self.demo["text"] = "dont click me"
    self.demo["command"] = self.dem
    self.demo.pack(side = "bottom", expand = "true", fill = "both")
  
  def end(self):
    time.sleep(5)
    exit()

  def pro(self):
    print(Fore.GREEN+"\nStarting... \n\n\n")
    #print(Fore.LIGHTCYAN_EX + "\nWould you like to find the area / volume of a \n2D[1] or \n3D[2] object?\n")
    self.anim["text"] = "Would you like to find the area / volume of a 2D[1] or 3D[2] object?"
    self.anim.pack(side="bottom")
    self.anim.update()
    x = input(Fore.LIGHTCYAN_EX + "\nWould you like to find the area / volume of a \n2D[1] or \n3D[2] object?\n")
    for i in range (0,1,1):
      if self.inp == 1 or x == '1': 
        self.anim["text"] = "Which of the following would you like to find the area of:  \nSquare[1], Circle[2], Triangle[3], Pentagon[4], Hexagon[5], Rhombus[6]?"
        self.anim.pack(side="bottom")
        self.anim.update()  
        y = input("Which of the following would you like to find the area of: \n Square[1], Circle[2], Triangle[3], Pentagon[4], Hexagon[5], Rhombus[6]?\n ")
        
        if self.inp == 1 or y == '1': 
          self.anim["text"] = "What is the side length of the square?"
          self.anim.pack(side="bottom")
          self.anim.update()
          z = input("What is the side length of the square? \n")
          x= square_area(self.inp)
          print(Fore.WHITE+ "Your area is: "+Fore.GREEN+x)
          #self.create_text("Your area is"+x)
          self.anim["text"] = "Your area is "+x
          self.anim.pack(side="bottom")
          self.anim.update()
        elif self.inp == 2 or y == '2':
          self.anim["text"] = "What is the radius of the circle?"
          self.anim.pack(side="bottom")
          self.anim.update()
          z = input("What is the radius of the circle? \n")
          x=circle_area(self.inp)
          print(Fore.WHITE+"Your area is: "+Fore.GREEN+x)
          #self.create_text("Your area is: " + x)
          self.anim["text"] = "Your area is "+x
          self.anim.pack(side="bottom")
          self.anim.update()
        elif self.inp == 3 or y == '3':
          self.anim["text"] = "What is the base of the triangle?"
          self.anim.pack(side="bottom")
          self.anim.update()
          z = input("What is the base of the triangle? \n")
          z = self.inp
          self.anim["text"] = "What is the height of the triangle?"
          self.anim.pack(side="bottom")
          self.anim.update()
          z2 = input("What is the height of the triangle? \n")
          z2 = self.inp
          x = triangle_area(z2,z)
          print(Fore.WHITE+"Your Area is "+Fore.GREEN+x)
          #self.create_text("Your area is "+x)
          self.anim["text"] = "Your area is " + x
          self.anim.pack(side="bottom")
          self.anim.update()
        elif self.inp == 4 or y == '4':
          self.anim["text"] = "What is the side length of the pentagon?"
          self.anim.pack(side="bottom")
          self.anim.update()
          x = input("What is the side length of the pentagon? \n")
          y = pentagon_area(self.inp)
          print(Fore.WHITE+"Your Area is "+Fore.GREEN+str(y))
          #self.create_text("Your area is "+y)
          self.anim["text"] = "Your area is "+y
          self.anim.pack(side="bottom")
          self.anim.update()
          
          
          #1/4*sqrt(5(5+2sqrt5))a^2
        elif self.inp == 5 or y == '5':
          self.anim["text"] = "What is the side length of the hexagon?"
          self.anim.pack(side="bottom")
          self.anim.update()
          a = input("What is the side length of the hexagon?\n")
          # hexagon area sl * a * 3 1
          ha = hexagon_area(self.inp)
          print(Fore.WHITE+"Your Area is "+Fore.GREEN + ha )
          #self.create_text("Your area is "+ha)
          self.anim["text"] = "Your area is "+ha
          self.anim.pack(side="bottom")
          self.anim.update()

        elif self.inp == 6 or y == '6':
          self.anim["text"] = "What is the length of the diagonal?"
          self.anim.pack(side="bottom")
          self.anim.update()
          d1 = input("What is the length of a diagonal?\n")
          d1 = self.inp
          self.anim["text"] = "What is the length of the other diagonal?"
          self.anim.pack(side="bottom")
          self.anim.update()
          d2 = input("What is the length of the other diagonal?\n")
          d2 = self.inp
          ra = rhombus_area(d1,d2)
          print(Fore.WHITE+"Your Area is "+Fore.GREEN + ra) 
          #self.create_text("Your area is "+ra)
          self.anim["text"] = "Your area is " + ra
          self.anim.pack(side="bottom")
          self.anim.update()
          
        #else:
        #  print(Fore.LIGHTCYAN_EX+"\nPlease enter a valid number\n" + Fore.RED+"OR ELSE")
      elif self.inp == 2 or x == '2':
        self.anim["text"] = "Volume[1] or surface area[2]?"
        self.anim.pack(side="bottom")
        self.anim.update()
        y = input("Volume[1] or surface area [2]?\n")
        if(self.inp == 1 or y == '1'):
          self.anim["text"] = "Which of the following would you like to find the volume of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6]"
          self.anim.pack(side="bottom")
          self.anim.update()
          y = input(
              "Which of the following would you like to find the volume of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6]\n")
          if self.inp == 1 or y == '1':
            self.anim["text"] = "Enter the radius"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the radius ")
            z = sphere_vol(self.inp)
          elif self.inp == 2 or y == '2':
            self.anim["text"] = "Enter the side length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the side length ")
            z = cube_vol(self.inp)
          elif self.inp == 3 or y == '3':
            self.anim["text"] = "Enter the base radius"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the base radius ")
            i1 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the height ")
            i2 = self.inp
            z = cylinder_vol(i1, i2)
          elif self.inp == 4 or y == '4':
            self.anim["text"] = "Enter the width"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the width ")
            i1 = self.inp
            self.anim["text"] = "Enter the length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the length ")
            i2 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i3 = input("Enter the height ")
            i3 = self.inp
            z = cuboid_vol(i1, i2, i3)
          elif self.inp == 5 or y == '5':
            i1 = input("Enter the radius of the base circle ")
            i2 = input("Enter the height of the cone ")
            z = cone_vol(i1, i2)
          elif self.inp == 6 or y == '6':
            self.anim["text"] = "Enter the length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the length ")
            i1 = self.inp
            self.anim["text"] = "Enter the width"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the width ")
            i2 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i3 = input("Enter the height ")
            i3 = self.inp
            z = pyramid_vol(i1, i2, i3)
          #elif y == '7':
          #  z = input("What type of prism would you like to find the volume of: Triangular[1], Pentagonal[2],or Hexgonal[3] ")
          #  if z == '1':
          #    z1 = float(input("What is the base of the triangle? "))
          #  
          #  else:
          #    print("Please enter a valid number")
            #if z == '2':
              #z1 = float(input("What is the side length of the pentagon? "))
              #z2 = float(input("What is the height of the prism? "))
          print(Fore.WHITE + "Your Volume is " + Fore.GREEN + z)
          self.anim["text"] = "Your Volume is " + z
          self.anim.pack(side="bottom")
          self.anim.update()
          #else:
          #  print(Fore.LIGHTCYAN_EX + "\nPlease enter a valid number\n")
          
          #self.create_text("Your volume is " +z)
        elif(self.inp == 2 or y == '2'):
          self.anim["text"] = "Which of the following would you like to find the surface area of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6], Prism[7]"
          self.anim.pack(side="bottom")
          self.anim.update()
          y = input(
              "Which of the following would you like to find the surface area of  \n  Sphere[1], Cube[2], Cylinder[3], Cuboid[4], Cone[5], Pyramid[6], Prism[7]\n")
          if self.inp == 1 or y == '1':
            self.anim["text"] = "Enter the radius "
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the radius: ")
            z = sphere_sa(self.inp)
            #print(Fore.WHITE + "Your surface area is"+Fore.GREEN + z)
          elif self.inp == 2 or y == '2':
            self.anim["text"] = "Enter the side length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the side legth: ")
            z = cube_sa(self.inp)
            #print(Fore.WHITE + "The surface area is" + Fore.GREEN + z)
          elif self.inp == 3 or y == '3':
            self.anim["text"] = "Enter the radius"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the radius: ")
            i1 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the height: ")
            i2 = self.inp
            z = cylinder_sa(i1, i2)
            #print(Fore.WHITE + "Your surface area is" + Fore.GREEN + z)
          elif self.inp == 4 or y == '4':
            self.anim["text"] = "Enter the length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the length: ")
            i1 = self.inp
            self.anim["text"] = "Enter the width"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the width: ")
            i2 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i3 = input("Enter the height: ")
            i3 = self.inp
            z = cuboid_sa(i1, i2, i3)
            #print(Fore.WHITE + "Your surface area is" + Fore.GREEN + z)
          elif self.inp == 5 or y == '5':
            self.anim["text"] = "Enter the side radius"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the radius: ")
            i1 = self.inp
            self.anim["text"] = "Enter the side height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the height: ")
            i2 = self.inp
            z = cone_sa(i1, i2)
            #print(Fore.WHITE + "Your surface area is" + Fore.GREEN + z)
          elif self.inp == 6 or y == '6':
            self.anim["text"] = "Enter the length"
            self.anim.pack(side="bottom")
            self.anim.update()
            i1 = input("Enter the length: ")
            i1 = self.inp
            self.anim["text"] = "Enter the width"
            self.anim.pack(side="bottom")
            self.anim.update()
            i2 = input("Enter the width: ")
            i2 = self.inp
            self.anim["text"] = "Enter the height"
            self.anim.pack(side="bottom")
            self.anim.update()
            i3 = input("Enter the height: ")
            i3 = self.inp
            z = pyramid_sa(i1, i2, i3)
            #print(Fore.WHITE + "Your surface area is" + Fore.GREEN + z)
          elif self.inp == 7 or y == '7':
            self.anim["text"] = "Which prism do you want the surface area of: Pentagonal[1], Hexagonal[2]"
            self.anim.pack(side="bottom")
            self.anim.update()
            y = input("Which prism do you want the surface area of: Pentagonal[1], Hexagonal[2] \n")
            #if y == '1':
            #  i1 = float(input("\nEnter the base length: \n"))
            #  i2 = float(input("Enter the height: \n"))
            #  z = tripris_sa(i1, i2)
            if y == 1:
              self.anim["text"] = "Enter the base length"
              self.anim.pack(side="bottom")
              self.anim.update()
              i1 = input("\nEnter the base length: \n")
              i1 = self.inp
              self.anim["text"] = "Enter the height "
              self.anim.pack(side="bottom")
              self.anim.update()
              i2 = input("Enter the height: \n")
              i2 = self.inp
              z = petpris_sa(i1, i2)
            elif y == 2:
              self.anim["text"] = "Enter the base length"
              self.anim.pack(side="bottom")
              self.anim.update()
              i1 = input("\nEnter the base length: \n")
              i1 = self.inp
              self.anim["text"] = "Enter the height"
              self.anim.pack(side="bottom")
              self.anim.update()
              i2 = input("Enter the height: \n")
              i2 = self.inp
              z = hexpris_sa(i1, i2)
            #else:
            #  print(Fore.RED + "Please enter a valid number")
            else:
              z = "error"
          #else:
          #  print("Please enter a valid number")
          print("Your surface area is "+ Fore.GREEN + z)
          #self.create_text("Your surface area is "+z)
          self.anim["text"] = "Your surface area is " + z
          self.anim.pack(side="bottom")
          self.anim.update()
        #else:
        #  print("Please enter a valid number")
      else:
        i-=1
        print(i)
      #  print(Fore.WHITE + "\nPlease enter a valid number\n")
      #  time.sleep(1.5)
      #  print(Fore.RED + "OR ELSE")

root = tk.Tk()
root.title("VOLUME & AREA CALCULATOR")
root.geometry("800x700")
root.configure(background='lightgray')
path = 'sphere.gif'
img = ImageTk.PhotoImage(Image.open(path))
panel = tk.Label(root, image = img)
panel.pack(side = "bottom")
textc = tk.Frame(root, width = 300, height = 160)
text = tk.Label(root, text = "VOLUME AND AREA CALCULATOR")
text.pack(side = "top", fill = "both", expand = "yes")

anim = tk.Label(root)
anim["text"] = "click start to continue"
anim.pack()

app = tkc(master = root, anim = anim)
app.mainloop()

#'''
